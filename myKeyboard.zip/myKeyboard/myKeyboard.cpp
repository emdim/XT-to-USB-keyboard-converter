#include "myKeyboard.h"
#include "Platform.h"
#include "USBAPI.h"
#include "USBDesc.h"

#define WEAK __attribute__ ((weak))

void WEAK HID_SendReport(u8 id, const void* data, int len)
{
	USB_Send(HID_TX, &id, 1);
	USB_Send(HID_TX | TRANSFER_RELEASE,data,len);
}

myKeyboard::myKeyboard() {}

void myKeyboard::sendReport(KeyReport* keys)
{
	HID_SendReport(2,keys,sizeof(KeyReport));
}

// press() adds the specified key scancode
// to the persistent key report and sends the report.  Because of the way
// USB HID works, the host acts like the key remains pressed until we
// call release(), releaseAll(), or otherwise clear the report and resend.
size_t myKeyboard::press_sc(uint8_t k)
{
	uint8_t i;

	if (k >= 224 && k <= 231) {
		_keyReport.modifiers |= (1 << (k - 224));
	}
	// Add k to the key report only if it's not already present
	// and if there is an empty slot.
	else if (_keyReport.keys[0] != k && _keyReport.keys[1] != k &&
		_keyReport.keys[2] != k && _keyReport.keys[3] != k &&
		_keyReport.keys[4] != k && _keyReport.keys[5] != k) {

		for (i=0; i<6; i++) {
			if (_keyReport.keys[i] == 0x00) {
				_keyReport.keys[i] = k;
				break;
			}
		}
		if (i == 6) {
			//setWriteError();
			return 0;
		}
	}
	sendReport(&_keyReport);
	return 1;
}

size_t myKeyboard::release_sc(uint8_t k)
{
	uint8_t i;

	if (k >= 224 && k <= 231) {
		_keyReport.modifiers &= ~(1 << (k - 224));
	}
	// Test the key report to see if k is present.  Clear it if it exists.
	// Check all positions in case the key is present more than once (which it shouldn't be)
	else {
		for (i=0; i<6; i++) {
			if (0 != k && _keyReport.keys[i] == k) {
				_keyReport.keys[i] = 0x00;
			}
		}
	}
	sendReport(&_keyReport);
	return 1;
}

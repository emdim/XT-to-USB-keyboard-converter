#ifndef myKeyboard_h
#define myKeyboard_h

#include "Arduino.h"

#if ARDUINO >= 10606
	#include <Keyboard.h>
	#define HID_SendReport(id,data,len) HID().SendReport(id,data,len)
#endif

class myKeyboard
{
  public:
    myKeyboard();
    void sendReport(KeyReport* keys);
	size_t press_sc(uint8_t k);
	size_t release_sc(uint8_t k);
  private:
	KeyReport _keyReport;
};

#endif
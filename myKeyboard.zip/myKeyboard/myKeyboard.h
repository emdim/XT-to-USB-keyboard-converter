#ifndef myKeyboard_h
#define myKeyboard_h

#include "Arduino.h"

#if ARDUINO >= 10606
	#include <Keyboard.h>
	#define HID_SendReport(id,data,len) HID().SendReport(id,data,len)
#else
	#include "Platform.h"
	#define WEAK __attribute__ ((weak))

	void WEAK HID_SendReport(u8 id, const void* data, int len)
	{
		USB_Send(HID_TX, &id, 1);
		USB_Send(HID_TX | TRANSFER_RELEASE,data,len);
	}
#endif

class myKeyboard
{
  public:
    myKeyboard();
    void sendReport(KeyReport* keys);
	size_t press_sc(uint8_t k);
	size_t release_sc(uint8_t k);
  private:
	KeyReport _keyReport;
};

#endif